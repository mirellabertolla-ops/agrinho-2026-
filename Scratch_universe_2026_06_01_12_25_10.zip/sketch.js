// Variáveis para controlar o crescimento das plantas
let plantas = [];
let maxPlantas = 120;

function setup() {
  createCanvas(600, 400);
}

function draw() {
  // 1. Cenário: Céu com degradê simples ou cor firme
  background(220, 245, 255); // Céu azul claro claro
  
  // Sol do Agrinho
  fill(255, 204, 0);
  noStroke();
  ellipse(100, 80, 70, 70);
  
  // 2. Montanhas ao fundo (Representando a natureza)
  fill(100, 180, 100);
  triangle(150, 400, 350, 200, 550, 400);
  fill(120, 200, 120);
  triangle(300, 400, 480, 230, 650, 400);

  // 3. Solo fértil (Terra onde vamos plantar)
  fill(110, 70, 45); // Marrom escuro da terra
  rect(0, 300, 600, 100);
  
  fill(75, 140, 75); // Linha da grama
  rect(0, 300, 600, 10);

  // 4. Ciclo para desenhar e fazer crescer cada planta semeada
  for (let i = 0; i < plantas.length; i++) {
    let p = plantas[i];
    
    // Se a planta ainda não chegou no tamanho máximo, ela cresce devagar
    if (p.tamanho < p.tamanhoMaximo) {
      p.tamanho += 0.5; 
    }
    
    // Desenha o caule/tronco da planta
    stroke(100, 65, 40);
    strokeWeight(p.tamanho * 0.15);
    line(p.x, 300, p.x, 300 - p.tamanho);
    
    // Desenha as folhas verdes (fruto/copa)
    noStroke();
    fill(34, 139, 34);
    ellipse(p.x, 300 - p.tamanho, p.tamanho * 0.6, p.tamanho * 0.6);
    
    // Adiciona um fruto/flor vermelha se a árvore estiver bem grande
    if (p.tamanho > 40) {
      fill(255, 50, 50);
      ellipse(p.x - 5, 295 - p.tamanho, 6, 6);
      ellipse(p.x + 7, 305 - p.tamanho, 5, 5);
    }
  }

  // 5. Textos informativos na tela
  fill(40);
  noStroke();
  textSize(20);
  text("Agrinho: Cultivando o Futuro", 20, 40);
  
  textSize(14);
  text("Clique na terra (área marrom) para semear!", 20, 65);
  text("Árvores plantadas: " + plantas.length, 20, 90);
}

// Função do p5.js que detecta o clique do mouse
function mousePressed() {
  // Só planta se o clique for na área da terra (Y maior que 300)
  if (mouseY > 300 && plantas.length < maxPlantas) {
    // Adiciona uma nova planta na lista com tamanho inicial zero
    plantas.push({
      x: mouseX,
      tamanho: 0,
      tamanhoMaximo: random(40, 75) // Cada árvore cresce até um tamanho diferente
    });
  }
}
  



  
